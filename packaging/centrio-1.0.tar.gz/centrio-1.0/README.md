# Centrio Installer

A modernized GTK installer for Oreon and other Linux distributions.

Centrio is still work in progress, please wait for more info coming in the near future.
