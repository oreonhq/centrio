#!/usr/bin/env python3

# Centrio Installer
# Copyright (C) 2026 Oreon HQ
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <https://www.gnu.org/licenses/>.
#
"""
Centrio Installer - Main entry point
"""

import sys
import os
import platform

# work around MESA "Failed to attach to x11 shm" (common on ARM/Wayland)
if platform.machine().lower() in ("aarch64", "arm64"):
    for k, v in [
        ("LIBGL_ALWAYS_SOFTWARE", "1"),
        ("GALLIUM_DRIVER", "llvmpipe"),
        ("QT_X11_NO_MITSHM", "1"),
    ]:
        os.environ[k] = v
import subprocess
import logging
import gettext
import locale
from pathlib import Path

# --- Privileged helper mode (for live session: oreon-installer-priv runs us as root) ---
if "--backend=priv" in sys.argv:
    idx = sys.argv.index("--backend=priv")
    cmd_argv = sys.argv[idx + 1:]
    if not cmd_argv:
        sys.exit(1)
    try:
        result = subprocess.run(cmd_argv, stdin=sys.stdin, timeout=None)
        sys.exit(result.returncode)
    except FileNotFoundError:
        print(f"Command not found: {cmd_argv[0]}", file=sys.stderr)
        sys.exit(127)
    except Exception as e:
        print(str(e), file=sys.stderr)
        sys.exit(1)

# Set up logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(filename)s:%(lineno)d - %(message)s'
)

# File where chosen installer language is stored (restart picks it up)
INSTALLER_LANG_FILE = os.environ.get(
    "CENTRIO_INSTALLER_LANG_FILE",
    os.path.join(os.environ.get("XDG_RUNTIME_DIR", "/tmp"), "centrio_installer_lang")
)


def setup_i18n():
    """Set up internationalization from installer language file or system locale."""
    # When installed: /usr/share/centrio/main.py -> parent = /usr/share/centrio
    # When development: src/main.py -> parent = src, parent.parent = repo root
    _dir = Path(__file__).resolve().parent
    project_root = _dir.parent if (_dir / "locale").exists() else _dir
    locale_dir = str(project_root / "locale")

    current_locale = None
    if os.path.isfile(INSTALLER_LANG_FILE):
        try:
            with open(INSTALLER_LANG_FILE, "r", encoding="utf-8") as f:
                current_locale = f.read().strip()
            if current_locale and ".UTF-8" not in current_locale and "." not in current_locale:
                current_locale = f"{current_locale}.UTF-8"
        except Exception as e:
            print(f"Warning: Could not read installer lang file: {e}")

    if not current_locale:
        current_locale = locale.getlocale()[0]
    if not current_locale:
        current_locale = os.environ.get("LANG", "en_US") or "en_US"
    if current_locale and ".UTF-8" not in current_locale and "." not in current_locale:
        current_locale = f"{current_locale}.UTF-8"

    try:
        os.environ["LANG"] = current_locale
        os.environ["LC_ALL"] = current_locale
        locale.setlocale(locale.LC_ALL, current_locale)
    except locale.Error:
        try:
            locale.setlocale(locale.LC_ALL, "")
        except locale.Error:
            pass

    gettext.install("centrio", localedir=locale_dir)
    print(f"Internationalization set up for locale: {current_locale}")
    return current_locale


def main():
    """Main entry point for the Centrio installer."""
    setup_i18n()

    # Optional: --frontend=gis (run in GNOME Initial Setup / live kiosk; no extra handling needed)
    if "--frontend=gis" in sys.argv:
        pass  # Run GUI as usual; GIS/kiosk is environment

    # Point Qt at the system plugin directory so it finds:
    #   - breeze6.so         (Breeze widget style)
    #   - KDEPlasmaPlatformTheme6.so  (color scheme, fonts, icons from KDE settings)
    # PySide6 installed via pip ships its own bundled plugins and ignores /usr/lib64.
    os.environ.setdefault("QT_PLUGIN_PATH", "/usr/lib64/qt6/plugins")

    # Load the KDE platform theme - this is what gives you the exact colors,
    # font and icon set from the user's KDE System Settings (Breeze color scheme,
    # Breeze icons, etc).  Without this you get Breeze widget shapes but default
    # Qt colors, which is exactly what looked wrong.
    os.environ.setdefault("QT_QPA_PLATFORMTHEME", "kde")

    from PySide6.QtWidgets import QApplication, QStyleFactory
    from window import CentrioInstallerWindow

    app = QApplication(sys.argv)

    # The KDE platform theme sets the style automatically to Breeze when running
    # on KDE.  If for some reason it didn't (non-KDE live session), force it.
    styles = {s.lower(): s for s in QStyleFactory.keys()}
    if app.style().objectName().lower() != "breeze":
        if "breeze" in styles:
            app.setStyle(styles["breeze"])
        else:
            app.setStyle(styles.get("fusion", app.style().objectName()))
            logging.warning("Breeze style not available, falling back to Fusion.")

    # Only semantic overrides - Breeze + KDE platform theme handle everything else.
    app.setStyleSheet(
        """
        QLabel#pageTitle {
            font-size: 22pt;
            font-weight: 700;
        }
        QPushButton#primaryButton {
            background-color: palette(highlight);
            color: palette(highlighted-text);
            font-weight: 600;
        }
        QPushButton#dangerButton {
            background-color: palette(highlight);
            color: palette(highlighted-text);
            font-weight: 600;
        }
        """
    )
    installer_script = os.path.abspath(sys.argv[0])
    logging.info("Centrio Installer starting...")
    win = CentrioInstallerWindow(installer_script=installer_script)
    win.installer_lang_file = INSTALLER_LANG_FILE
    win.show()
    return app.exec()

if __name__ == "__main__":
    sys.exit(main()) 